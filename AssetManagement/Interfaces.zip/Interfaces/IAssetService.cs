﻿using AssetManagement.Models;

namespace AssetManagement.Interfaces
{
    public interface IAssetService : IRepository<int, Asset>
    {
        Task<IEnumerable<Asset>> GetAssetsByCategoryAsync(int categoryId);
        Task<IEnumerable<Asset>> GetAssetsByStatusAsync(int statusId);
    }
}
