﻿using AssetManagement.Models;
using AssetManagement.Models.DTOs.Auth;

namespace AssetManagement.Interfaces
{
    public interface IAuthenticate
    {
        Task<LoginResponseDTO?> LoginAsync(LoginRequestDTO request);
        Task<bool> RegisterAsync(RegisterRequestDTO request);
    }
}
