﻿using AssetManagement.Models;
using AssetManagement.Models.DTOs.Auth;

namespace AssetManagement.Interfaces
{
    public interface ITokenService
    {
        string GenerateToken(TokenUserDTO user);
    }
}
