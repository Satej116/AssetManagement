﻿using AssetManagement.Models;

namespace AssetManagement.Interfaces
{
    public interface IEmployeeService : IRepository<int, Employee>
    {
        Task<Employee?> GetEmployeeByIdAsync(int employeeId);

    }
}
